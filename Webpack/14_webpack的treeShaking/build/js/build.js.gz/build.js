/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
/*!**********************************!*\
  !*** ./src/index.js + 2 modules ***!
  \**********************************/

;// CONCATENATED MODULE: ./src/math.js
function add(num1, num2) {
  return num1 + num2
}

function mul(num1, num2) {
  return num1 -num2
}
;// CONCATENATED MODULE: ./src/css/style.css
// extracted by mini-css-extract-plugin

;// CONCATENATED MODULE: ./src/index.js




console.log("hello")
console.log(add(10, 20));

const h2El = document.createElement("h2")
h2El.innerHTML = "hello"
document.body.appendChild(h2El)

const divEl = document.createElement("div")
divEl.className = "content"
document.body.appendChild(divEl)
/******/ })()
;
//# sourceMappingURL=build.js.map